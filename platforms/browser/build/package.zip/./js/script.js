$(document).on('pagecreate','#home',function(){

  $('#upload').on('submit',function(e){
      e.preventDefault();

      console.log($('#file').val());
      //var url = 'http://localhost:8027/public_html/camfind/ajax_upload.php';
      var url = 'http://raveteam.net/camfind/ajax_upload.php';
      
      $('#message').empty();
      $.ajax({
           url: url,
           type: 'POST',
           data: new FormData(this),
           contentType: false,
           crossDomain: true,
           cache: false,
           processData: false,
           dataType: 'json',
           success: function(data){
             console.log(data);
             $('#fruit_name').html(data['fruitname']);
             $("#message").html(data['message']);
           },
           error: function(data){
             console.log('Error');
             console.log(data);
           }
         });
    });


});
